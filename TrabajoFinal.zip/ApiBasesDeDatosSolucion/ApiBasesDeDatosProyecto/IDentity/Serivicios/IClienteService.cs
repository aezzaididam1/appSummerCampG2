﻿public interface IClienteService
{
    Task RegisterClientAsync(Cliente cliente);
}

﻿public class IdentitySettings
{
    public PasswordSettings Password { get; set; }
    public LockoutSettings Lockout { get; set; }
}


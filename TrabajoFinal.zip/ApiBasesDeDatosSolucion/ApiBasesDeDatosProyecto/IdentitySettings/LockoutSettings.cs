﻿public class LockoutSettings
{
    public int DefaultLockoutMinutes { get; set; }
    public int MaxFailedAccessAttempts { get; set; }
}
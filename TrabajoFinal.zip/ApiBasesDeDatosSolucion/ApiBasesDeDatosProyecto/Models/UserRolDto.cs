﻿public class UserRoleDto
{
    public string Email { get; set; }
    public string Rol { get; set; }
}

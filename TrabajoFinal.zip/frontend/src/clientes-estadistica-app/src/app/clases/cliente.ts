export class Cliente {
  id: number;
  nombre: string;
  apellido: string;
  fechaNacimiento: number;
  nombrePais: string;
  empleo?: string;
  paisId: number;
  email: string;
}

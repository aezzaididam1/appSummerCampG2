import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outliers-detail',
  templateUrl: './outliers-detail.component.html',
  styleUrls: ['./outliers-detail.component.css']
})
export class OutliersDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}

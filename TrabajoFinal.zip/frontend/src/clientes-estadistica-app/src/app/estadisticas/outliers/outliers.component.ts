import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outliers',
  templateUrl: './outliers.component.html',
  styleUrls: ['./outliers.component.css']
})
export class OutliersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

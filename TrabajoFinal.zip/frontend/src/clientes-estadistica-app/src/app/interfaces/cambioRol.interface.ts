export interface CambioRolModel {
    Email: string;
    NuevoRol: string;
    Nombre?: string;
    Apellido?: string;
    Pais?: string;
    Empleo?: string;
    FechaNacimiento: string;
  }
  
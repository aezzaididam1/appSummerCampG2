export interface IEnvio {
    id: number;
    divisa: string;
    cantidad: number;
    fecha: Date;
}

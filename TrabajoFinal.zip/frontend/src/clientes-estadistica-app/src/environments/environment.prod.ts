export const environment = {
    production: true,
    apiUrl: 'https://backend-estadistica-g6afbvbagbe3d6gr.spaincentral-01.azurewebsites.net/api/usuarios'
  };
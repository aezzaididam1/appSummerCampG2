export const environment = {
    production: false,
    apiUrl: 'https://localhost:7144/api/usuarios'
  };